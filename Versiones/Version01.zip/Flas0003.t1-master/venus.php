
<center>
    <h1 id="tituP">Planeta Venus</h1>
    <img src="img/Venus.jpg" alt=""/>
</center>