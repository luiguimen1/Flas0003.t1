<?php

if ($_POST) {
    ?>
    <center>
        <h1 id="tituP">Planeta Mercurio</h1>
        <img src="img/mercurio.jpg" alt=""/>
    </center>
    <?php

} else {
    header("location: ./");
}