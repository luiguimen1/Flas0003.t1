<center>
    <h1 id="tituP">Planeta TIERRA</h1>
    <img src="img/tierra.jpg" alt=""/>
</center>